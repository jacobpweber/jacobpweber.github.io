// NY Fed results: Figure 1, Table 1 Panel A, Table 3 columns 1-3,
// Table 4, and Table B1. Chair results require separately obtained data.
// Run from the folder containing clean_NY_Fed_president_speech_dataset.dta;
// all outputs are written to that folder. To use another folder, set cd here.
clear all
set more off
use "clean_NY_Fed_president_speech_dataset.dta", clear

// Key summary statistics: of 223, non-testimony speeches for which we have a time stamp:
tab overlapping_data_release // 50 have a conflicting data release potentially needing a window adjustment
tab yield_movement_associated_with_d // of which 17 moved markets, so we adjust the window

// 216 have matched speech text, and 30 have matched Q&A text (13.9%)
codebook interview_transc_filename_noext speech_transc_filename_noext , c


// NY Fed replication. The topic-frequency figure and phrase table require
// the clustered text corpus and are not reproducible from this dataset alone.
foreach cmd in eststo estadd esttab {
    capture which `cmd'
    if _rc {
        display as error "The estout package is required. Install it with: ssc install estout"
        exit 499
    }
}

// Figure 1 and the alternate ED2-ED4 plots, matching 7h.
preserve
gen long plot_original_order = _n
local date_ticks
forvalues y = 2005(2)2023 {
    local tick = mdy(1, 1, `y')
    local date_ticks `date_ticks' `tick'
}
foreach var in ed1 ed2 ed3 ed4 {
    gen double plot_bp = 100 * `var'
    gen double plot_abs = abs(plot_bp)
    gsort -plot_abs statadate plot_original_order
    gen str12 plot_label = string(statadate, "%tdDDmonCCYY") if _n <= 5 & !missing(`var')
    gen byte plot_label_position = 12
    replace plot_label_position = 6 if plot_bp < 0
    replace plot_label_position = 9 if _n <= 5 & year(statadate) >= 2021
    local series_label = upper("`var'")
    twoway ///
        (scatter plot_bp statadate if infoaboutmonetarypolicy == 0, ///
            mcolor(navy%65) msymbol(O) msize(small)) ///
        (scatter plot_bp statadate if infoaboutmonetarypolicy == 1, ///
            mcolor(cranberry) msymbol(D) msize(small)) ///
        (scatter plot_bp statadate if plot_label != "", ///
            msymbol(none) mlabel(plot_label) mlabcolor(black) mlabsize(small) ///
            mlabvposition(plot_label_position)), ///
        yline(0, lcolor(gs10)) ylabel(, angle(horizontal)) ///
        xlabel(`date_ticks', format(%tdCCYY)) xtitle("") ///
        ytitle("`series_label' rate change (basis points)") ///
        legend(order(1 "Other speeches" 2 "Monetary-policy relevant") rows(1) position(6)) ///
        graphregion(color(white)) plotregion(color(white))
    graph export "NY_Figure1_`var'.pdf", replace
    drop plot_bp plot_abs plot_label plot_label_position
}
restore

// Table 1, Panel A: NY Fed outcomes, in basis points (equity in log bp).
local assets ed1 ed4 tnote02 tnote10 sp500emini
matrix ny_summary = J(5, 3, .)
local i = 0
foreach asset of local assets {
    local ++i
    tempvar response
    generate double `response' = 100 * `asset' if infoaboutmonetarypolicy == 1
    quietly summarize `response'
    matrix ny_summary[`i', 1] = r(N)
    matrix ny_summary[`i', 3] = r(sd)
    replace `response' = abs(`response')
    quietly summarize `response', meanonly
    matrix ny_summary[`i', 2] = r(mean)
    drop `response'
}
matrix rownames ny_summary = ed1 ed4 tnote02 tnote10 sp500emini
matrix colnames ny_summary = N mean_abs SD
matrix list ny_summary
tempname summary_file
file open `summary_file' using "NY_Table1_PanelA.tex", write replace
file write `summary_file' "\begin{tabular}{lrr}\toprule" _n
file write `summary_file' "Asset & Mean abs. & SD \\ \midrule" _n
local label1 "ED1 (current quarter)"
local label2 "ED4 (three quarters ahead)"
local label3 "Two-year Treasury"
local label4 "Ten-year Treasury"
local label5 "S\&P 500 futures"
forvalues i = 1/5 {
    local mean : display %9.2f ny_summary[`i', 2]
    local sd : display %9.2f ny_summary[`i', 3]
    file write `summary_file' "`label`i'' & `mean' & `sd' \\" _n
}
file write `summary_file' "\bottomrule\end{tabular}" _n
file close `summary_file'

local controls i.speaker_name_numeric during_blackout days_to_next_mtg
local outcomes ed1 ed2 ed3 ed4 tnote02 tnote05 tnote10 tbond sp500emini

// Match the paper's labels and NY Fed group standardization.
local topic_BALANCE_SHEET "Balance Sheet"
local topic_DUAL_MANDATE "Dual Mandate"
local topic_FED_INDEPENDENCE "Fed Independence"
local topic_FINANCE_METRIC "Finance Metric"
local topic_FORWARD_GUIDANCE "Forward Guidance"
local topic_INFLATION_METRIC "Inflation Metric"
local topic_LABOR_MARKET_METRIC "Labor Market Metric"
local topic_MACRO_METRICS "Macro Metrics"
local topic_RATE_ACTION "Rate Action"
local topic_US_DEBT "U.S. Debt"
local topics BALANCE_SHEET DUAL_MANDATE FED_INDEPENDENCE FINANCE_METRIC ///
    FORWARD_GUIDANCE INFLATION_METRIC LABOR_MARKET_METRIC MACRO_METRICS RATE_ACTION US_DEBT
label variable infoaboutmonetarypolicy "MP Rel. Speech"
label variable during_blackout "Blackout period"
label variable sp_total_chunks "Sp: Total Mentions"
label variable qna_total_chunks "Q&A: Total Mentions"
label variable ed1 "ED1"
label variable ed2 "ED2"
label variable ed3 "ED3"
label variable ed4 "ED4"
label variable tnote02 "2Y Tsy"
label variable tnote05 "5Y Tsy"
label variable tnote10 "10Y Tsy"
label variable tbond "30Y Tsy"
label variable sp500emini "S&P 500"
foreach topic of local topics {
    label variable i_sp`topic' "Sp: `topic_`topic''"
    label variable i_qna`topic' "Q&A: `topic_`topic''"
    label variable sp_bd`topic' "Sp. Hawkishness: `topic_`topic''"
    label variable qna_bd`topic' "Q&A Hawkishness: `topic_`topic''"
}
foreach var of varlist sp_bd* qna_bd* {
    recast double `var'
    quietly summarize `var'
    if r(N) > 1 & r(sd) > 0 & !missing(r(sd)) {
        local mean = r(mean)
        local sd = r(sd)
        quietly replace `var' = (`var' - `mean') / `sd'
    }
}

// Table 3, columns 1-3: common speech-plus-Q&A complete-case sample.
tempvar table2_sample
mark `table2_sample'
markout `table2_sample' infoaboutmonetarypolicy sp_total_chunks qna_total_chunks ///
    i_sp* i_qna* speaker_name_numeric during_blackout days_to_next_mtg year
estimates clear
eststo reg_mp_1a, title("MP Rel. Speech (NY)"): areg infoaboutmonetarypolicy `controls' if `table2_sample', absorb(year) vce(robust)
estadd local obs "`e(N)'"
estadd local speaker_fe "Yes"
estadd local year_fe "Yes"
eststo reg_mp_1b, title("MP Rel. Speech (NY)"): areg infoaboutmonetarypolicy sp_total_chunks i_sp* `controls' if `table2_sample', absorb(year) vce(robust)
estadd local obs "`e(N)'"
estadd local speaker_fe "Yes"
estadd local year_fe "Yes"
eststo reg_mp_2, title("MP Rel. Speech (NY)"): areg infoaboutmonetarypolicy sp_total_chunks qna_total_chunks i_sp* i_qna* `controls' if `table2_sample', absorb(year) vce(robust)
estadd local obs "`e(N)'"
estadd local speaker_fe "Yes"
estadd local year_fe "Yes"
esttab reg_mp_* using "NY_Table3_relevance.tex", ///
    mtitles fragment label replace booktabs ///
    cells(b(star fmt(2)) se(par fmt(2))) collabels(none) substitute("Q&A" "Q\&A") ///
    drop(*cons* *.speaker_name_numeric days_to_next_mtg) nobaselevels ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    s(obs speaker_fe year_fe ar2, label("Observations" "Speaker fixed effects" "Year fixed effects" "Adj. \$R^2\$"))

	
// For the results with market responses on the LHS: 
*drop if statadate == td(21oct2022)  // outlier sensitivity; retained in the paper's main regressions


// Table 4: forward-guidance direction in speech and Q&A.
// Use basis points for rates and log basis points for equity returns.
preserve
foreach var of local outcomes {
    recast double `var'
    replace `var' = 100 * `var'
}
estimates clear
foreach var of local outcomes {
    local outcome_label : variable label `var'
    eststo reg_`var', title("`outcome_label'"): areg `var' sp_bdFORWARD_GUIDANCE qna_bdFORWARD_GUIDANCE `controls' wl_`var' wl_intday_`var', vce(robust) absorb(year)
    estadd local obs "`e(N)'"
}
esttab reg_* using "NY_Table4_forward_guidance.tex", ///
    mtitles fragment label replace booktabs ///
    cells(b(star fmt(2)) se(par fmt(2))) collabels(none) substitute("Q&A" "Q\&A" "S&P 500" "S\&P 500") ///
    drop(*cons* wl_* *.speaker_name_numeric during_blackout days_to_next_mtg) nobaselevels ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    s(obs ar2, label("Observations" "Adj. \$R^2\$"))

// Table B1: direction across all ten topics.
estimates clear
foreach var of local outcomes {
    local outcome_label : variable label `var'
    eststo reg_`var', title("`outcome_label'"): areg `var' sp_bd* qna_bd* `controls' wl_`var' wl_intday_`var', vce(robust) absorb(year)
    estadd local obs "`e(N)'"
}
esttab reg_* using "NY_TableB1.tex", ///
    mtitles fragment label replace booktabs ///
    cells(b(star fmt(2)) se(par fmt(2))) collabels(none) substitute("Q&A" "Q\&A" "S&P 500" "S\&P 500") ///
    drop(*cons* wl_* *.speaker_name_numeric during_blackout days_to_next_mtg) nobaselevels ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    s(obs ar2, label("Observations" "Adj. \$R^2\$"))
restore
